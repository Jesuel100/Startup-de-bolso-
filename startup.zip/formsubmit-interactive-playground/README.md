# FormSubmit Interactive Playground

A Pen created on CodePen.

Original URL: [https://codepen.io/Jesuel-Banze/pen/YPXmwEp](https://codepen.io/Jesuel-Banze/pen/YPXmwEp).

Connect your form to our form endpoint and we’ll email you the submissions. No PHP, Javascript, or any backend code is required.